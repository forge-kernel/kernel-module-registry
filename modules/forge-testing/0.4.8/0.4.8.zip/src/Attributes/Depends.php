<?php

declare(strict_types=1);

namespace Modules\ForgeTesting\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_METHOD)]
final class Depends
{
    public function __construct(
        public string $testMethod
    ) {
    }
}
