<?php

declare(strict_types=1);

use Modules\ForgeNotification\Enums\NotificationChannel;
use Modules\ForgeNotification\Payload\EmailPayload;
use Modules\ForgeNotification\Payload\PushPayload;
use Modules\ForgeNotification\Payload\SmsPayload;
use Modules\ForgeNotification\Services\ForgeNotificationService;
use Forge\Core\DI\Container;

if (!function_exists('sendNotification')) {
    /**
     * Send a notification via the specified channel.
     * This is the main entry point for sending notifications.
     *
     * @param NotificationChannel $channel The channel to send via
     * @param EmailPayload|SmsPayload|PushPayload $payload The notification data
     */
    function sendNotification(NotificationChannel $channel, EmailPayload|SmsPayload|PushPayload $payload): void
    {
        try {
            Container::getInstance()
                ->get(ForgeNotificationService::class)
                ->send($channel, $payload);
        } catch (\Throwable $e) {
            if (function_exists('collect_exception')) {
                collect_exception($e);
            }
        }
    }
}
